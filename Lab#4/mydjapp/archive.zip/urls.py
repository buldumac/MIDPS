from django.conf.urls import *
from mydjapp.views import posts, detail, categories

urlpatterns = patterns('',
    #url(r'^$', categories),
)